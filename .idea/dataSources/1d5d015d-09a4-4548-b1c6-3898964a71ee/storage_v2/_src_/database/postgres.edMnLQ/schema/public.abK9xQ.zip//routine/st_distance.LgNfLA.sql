create function st_distance(text, text
                           ) returns double precision
    language sql
as
$$
SELECT public.ST_Distance($1::public.geometry, $2::public.geometry);
$$;


create function st_addpoint(geom1 geometry, geom2 geometry
                           ) returns geometry
    language c
as
$$
LWGEOM_addpoint
$$;

comment on function st_addpoint(geometry, geometry) is 'args: linestring, point - Add a point to a LineString.';


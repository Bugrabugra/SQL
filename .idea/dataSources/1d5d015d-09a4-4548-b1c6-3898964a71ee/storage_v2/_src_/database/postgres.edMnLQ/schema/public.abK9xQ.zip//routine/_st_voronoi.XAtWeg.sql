create function "_st_voronoi"(g1 geometry, clip geometry DEFAULT NULL::geometry, tolerance double precision DEFAULT 0.0, return_polygons boolean DEFAULT true
                             ) returns geometry
    language c
as
$$
ST_Voronoi
$$;


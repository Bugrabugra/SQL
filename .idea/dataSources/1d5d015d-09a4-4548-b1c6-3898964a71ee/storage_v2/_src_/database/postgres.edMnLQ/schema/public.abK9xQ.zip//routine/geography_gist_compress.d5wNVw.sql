create function geography_gist_compress(internal
                                       ) returns internal
    language c
as
$$
gserialized_gist_compress
$$;


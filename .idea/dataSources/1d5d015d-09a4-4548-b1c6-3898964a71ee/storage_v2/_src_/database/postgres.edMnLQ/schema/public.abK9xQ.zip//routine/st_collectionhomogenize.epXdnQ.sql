create function st_collectionhomogenize(geometry
                                       ) returns geometry
    language c
as
$$
ST_CollectionHomogenize
$$;

comment on function st_collectionhomogenize(geometry) is 'args: collection - Given a geometry collection, return the "simplest" representation of the contents.';


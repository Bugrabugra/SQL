create function postgis_lib_version(
                                   ) returns text
    language c
as
$$
postgis_lib_version
$$;

comment on function postgis_lib_version() is 'Returns the version number of the PostGIS library.';


create function st_addmeasure(geometry, double precision, double precision
                             ) returns geometry
    language c
as
$$
ST_AddMeasure
$$;

comment on function st_addmeasure(geometry, float8, float8) is 'args: geom_mline, measure_start, measure_end - Return a derived geometry with measure elements linearly interpolated between the start and end points.';


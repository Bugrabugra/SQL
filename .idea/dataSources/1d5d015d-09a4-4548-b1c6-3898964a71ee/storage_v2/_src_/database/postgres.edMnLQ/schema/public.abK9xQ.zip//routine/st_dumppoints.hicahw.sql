create function st_dumppoints(geometry
                             ) returns SETOF geometry_dump
    language c
as
$$
LWGEOM_dumppoints
$$;

comment on function st_dumppoints(geometry) is 'args: geom - Returns a set of geometry_dump rows for the points in a geometry.';


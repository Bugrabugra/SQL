create function geometry_le(geom1 geometry, geom2 geometry
                           ) returns boolean
    language c
as
$$
lwgeom_le
$$;


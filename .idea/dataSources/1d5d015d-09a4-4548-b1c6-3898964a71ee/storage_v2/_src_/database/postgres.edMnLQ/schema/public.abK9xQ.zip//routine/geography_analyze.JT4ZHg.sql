create function geography_analyze(internal
                                 ) returns boolean
    language c
as
$$
gserialized_analyze_nd
$$;


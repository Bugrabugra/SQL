create function pgis_asmvt_combinefn(internal, internal
                                    ) returns internal
    language c
as
$$
pgis_asmvt_combinefn
$$;


create function geometry_distance_cpa(geometry, geometry
                                     ) returns double precision
    language c
as
$$
ST_DistanceCPA
$$;


create function pgis_geometry_makeline_finalfn(internal
                                              ) returns geometry
    language c
as
$$
pgis_geometry_makeline_finalfn
$$;


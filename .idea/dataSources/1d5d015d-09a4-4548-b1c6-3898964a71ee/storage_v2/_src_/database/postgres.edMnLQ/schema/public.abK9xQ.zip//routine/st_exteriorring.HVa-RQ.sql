create function st_exteriorring(geometry
                               ) returns geometry
    language c
as
$$
LWGEOM_exteriorring_polygon
$$;

comment on function st_exteriorring(geometry) is 'args: a_polygon - Returns a LineString representing the exterior ring of a Polygon.';


create function geography_gist_same(box2d, box2d, internal
                                   ) returns internal
    language c
as
$$
gserialized_gist_same
$$;


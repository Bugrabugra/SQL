create function postgis_dropbbox(geometry
                                ) returns geometry
    language c
as
$$
LWGEOM_dropBBOX
$$;

comment on function postgis_dropbbox(geometry) is 'args: geomA - Drop the bounding box cache from the geometry.';


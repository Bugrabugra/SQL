create function st_geomfromtwkb(bytea
                               ) returns geometry
    language c
as
$$
LWGEOMFromTWKB
$$;


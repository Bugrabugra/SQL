create function st_forcecollection(geometry
                                  ) returns geometry
    language c
as
$$
LWGEOM_force_collection
$$;

comment on function st_forcecollection(geometry) is 'args: geomA - Convert the geometry into a GEOMETRYCOLLECTION.';


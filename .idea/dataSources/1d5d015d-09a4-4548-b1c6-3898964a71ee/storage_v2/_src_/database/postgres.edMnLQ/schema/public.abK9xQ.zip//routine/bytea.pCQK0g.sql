create function bytea(geometry
                     ) returns bytea
    language c
as
$$
LWGEOM_to_bytea
$$;


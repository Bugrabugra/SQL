create function gserialized_gist_joinsel_2d(internal, oid, internal, smallint
                                           ) returns double precision
    language c
as
$$
gserialized_gist_joinsel_2d
$$;


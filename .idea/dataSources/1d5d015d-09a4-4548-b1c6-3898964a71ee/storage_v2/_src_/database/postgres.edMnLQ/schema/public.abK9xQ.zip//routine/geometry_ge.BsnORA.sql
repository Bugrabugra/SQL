create function geometry_ge(geom1 geometry, geom2 geometry
                           ) returns boolean
    language c
as
$$
lwgeom_ge
$$;


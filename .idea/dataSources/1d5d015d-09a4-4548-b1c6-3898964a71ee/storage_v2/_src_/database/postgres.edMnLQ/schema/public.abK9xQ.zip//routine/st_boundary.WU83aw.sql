create function st_boundary(geometry
                           ) returns geometry
    language c
as
$$
boundary
$$;

comment on function st_boundary(geometry) is 'args: geomA - Returns the boundary of a geometry.';


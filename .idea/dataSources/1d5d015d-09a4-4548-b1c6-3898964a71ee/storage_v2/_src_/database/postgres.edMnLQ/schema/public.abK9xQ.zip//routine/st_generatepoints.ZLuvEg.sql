create function st_generatepoints(area geometry, npoints integer
                                 ) returns geometry
    language c
as
$$
ST_GeneratePoints
$$;

comment on function st_generatepoints(geometry, int4) is 'args: g, npoints - Converts a polygon or multi-polygon into a multi-point composed of randomly location points within the original areas.';


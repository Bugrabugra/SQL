create function geography_out(geography
                             ) returns cstring
    language c
as
$$
geography_out
$$;


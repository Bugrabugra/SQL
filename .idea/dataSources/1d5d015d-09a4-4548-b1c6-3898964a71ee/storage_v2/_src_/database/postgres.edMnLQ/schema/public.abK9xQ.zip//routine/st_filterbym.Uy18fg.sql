create function st_filterbym(geometry, double precision, double precision DEFAULT NULL::double precision, boolean DEFAULT false
                            ) returns geometry
    language c
as
$$
LWGEOM_FilterByM
$$;

comment on function st_filterbym(geometry, float8, float8, bool) is 'args: geom, min, max = null, returnM = false - Filters vertex points based on their m-value';


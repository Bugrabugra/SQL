create function "_st_expand"(geography, double precision
                            ) returns geography
    language c
as
$$
geography_expand
$$;


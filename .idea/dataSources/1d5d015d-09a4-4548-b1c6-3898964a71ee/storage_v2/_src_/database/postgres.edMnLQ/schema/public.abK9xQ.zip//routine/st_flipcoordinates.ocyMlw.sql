create function st_flipcoordinates(geometry
                                  ) returns geometry
    language c
as
$$
ST_FlipCoordinates
$$;

comment on function st_flipcoordinates(geometry) is 'args: geom - Returns a version of the given geometry with X and Y axis flipped. Useful for people who have built latitude/longitude features and need to fix them.';


create function st_dfullywithin(geom1 geometry, geom2 geometry, double precision
                               ) returns boolean
    language c
as
$$
LWGEOM_dfullywithin
$$;


create function st_geogfromwkb(bytea
                              ) returns geography
    language c
as
$$
geography_from_binary
$$;


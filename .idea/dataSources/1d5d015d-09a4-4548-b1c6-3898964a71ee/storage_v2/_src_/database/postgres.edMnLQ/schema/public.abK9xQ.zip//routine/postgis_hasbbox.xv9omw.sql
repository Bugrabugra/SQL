create function postgis_hasbbox(geometry
                               ) returns boolean
    language c
as
$$
LWGEOM_hasBBOX
$$;

comment on function postgis_hasbbox(geometry) is 'args: geomA - Returns TRUE if the bbox of this geometry is cached, FALSE otherwise.';


create function geography_recv(internal, oid, integer
                              ) returns geography
    language c
as
$$
geography_recv
$$;


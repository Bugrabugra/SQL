create function geography_gist_decompress(internal
                                         ) returns internal
    language c
as
$$
gserialized_gist_decompress
$$;


create function st_delaunaytriangles(g1 geometry, tolerance double precision DEFAULT 0.0, flags integer DEFAULT 0
                                    ) returns geometry
    language c
as
$$
ST_DelaunayTriangles
$$;

comment on function st_delaunaytriangles(geometry, float8, int4) is 'args: g1, tolerance, flags - Return a Delaunay triangulation around the given input points.';


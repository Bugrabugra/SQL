create function st_estimatedextent(text, text
                                  ) returns box2d
    language c
as
$$
gserialized_estimated_extent
$$;

comment on function st_estimatedextent(text, text, text) is 'args: schema_name, table_name, geocolumn_name - Return the estimated extent of a spatial table.';


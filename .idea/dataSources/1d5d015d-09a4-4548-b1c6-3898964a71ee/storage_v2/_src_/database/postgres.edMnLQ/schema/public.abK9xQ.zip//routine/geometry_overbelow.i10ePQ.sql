create function geometry_overbelow(geom1 geometry, geom2 geometry
                                  ) returns boolean
    language c
as
$$
gserialized_overbelow_2d
$$;


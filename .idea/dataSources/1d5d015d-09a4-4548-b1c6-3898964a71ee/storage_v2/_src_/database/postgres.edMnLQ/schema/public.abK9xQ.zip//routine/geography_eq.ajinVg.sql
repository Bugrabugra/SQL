create function geography_eq(geography, geography
                            ) returns boolean
    language c
as
$$
geography_eq
$$;


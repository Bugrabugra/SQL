create function geometry_overleft(geom1 geometry, geom2 geometry
                                 ) returns boolean
    language c
as
$$
gserialized_overleft_2d
$$;


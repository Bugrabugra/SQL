create function postgis_scripts_released(
                                        ) returns text
    language c
as
$$
postgis_scripts_released
$$;

comment on function postgis_scripts_released() is 'Returns the version number of the postgis.sql script released with the installed postgis lib.';


create function st_extent(geometry
                         ) returns box2d
    language internal
as
$$
aggregate_dummy
$$;

comment on function st_extent(geometry) is 'args: geomfield - an aggregate function that returns the bounding box that bounds rows of geometries.';


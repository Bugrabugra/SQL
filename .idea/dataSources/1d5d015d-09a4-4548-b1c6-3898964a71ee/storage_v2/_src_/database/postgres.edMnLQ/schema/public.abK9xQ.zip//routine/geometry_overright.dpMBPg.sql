create function geometry_overright(geom1 geometry, geom2 geometry
                                  ) returns boolean
    language c
as
$$
gserialized_overright_2d
$$;


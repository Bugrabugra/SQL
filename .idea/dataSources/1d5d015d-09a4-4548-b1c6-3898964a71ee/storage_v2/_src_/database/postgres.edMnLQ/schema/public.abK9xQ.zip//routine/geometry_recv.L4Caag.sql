create function geometry_recv(internal
                             ) returns geometry
    language c
as
$$
LWGEOM_recv
$$;


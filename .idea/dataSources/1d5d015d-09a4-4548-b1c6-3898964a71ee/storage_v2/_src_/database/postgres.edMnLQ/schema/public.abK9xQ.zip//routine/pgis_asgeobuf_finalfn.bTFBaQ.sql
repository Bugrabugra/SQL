create function pgis_asgeobuf_finalfn(internal
                                     ) returns bytea
    language c
as
$$
pgis_asgeobuf_finalfn
$$;


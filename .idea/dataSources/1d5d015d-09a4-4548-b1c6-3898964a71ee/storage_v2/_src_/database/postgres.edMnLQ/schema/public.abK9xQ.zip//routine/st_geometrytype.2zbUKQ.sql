create function st_geometrytype(geometry
                               ) returns text
    language c
as
$$
geometry_geometrytype
$$;

comment on function st_geometrytype(geometry) is 'args: g1 - Returns the SQL-MM type of a geometry as text.';


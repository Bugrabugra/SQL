create function postgis_transform_geometry(geom geometry, text, text, integer
                                          ) returns geometry
    language c
as
$$
transform_geom
$$;


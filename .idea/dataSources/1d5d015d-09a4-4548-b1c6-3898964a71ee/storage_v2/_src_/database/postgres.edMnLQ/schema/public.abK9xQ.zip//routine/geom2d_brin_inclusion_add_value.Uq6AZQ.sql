create function geom2d_brin_inclusion_add_value(internal, internal, internal, internal
                                               ) returns boolean
    language c
as
$$
geom2d_brin_inclusion_add_value
$$;


create function gidx_in(cstring
                       ) returns gidx
    language c
as
$$
gidx_in
$$;


create function st_combinebbox(box3d, geometry
                              ) returns box3d
    language c
as
$$
BOX3D_combine
$$;


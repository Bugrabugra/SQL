create function postgis_libxml_version(
                                      ) returns text
    language c
as
$$
postgis_libxml_version
$$;

comment on function postgis_libxml_version() is 'Returns the version number of the libxml2 library.';


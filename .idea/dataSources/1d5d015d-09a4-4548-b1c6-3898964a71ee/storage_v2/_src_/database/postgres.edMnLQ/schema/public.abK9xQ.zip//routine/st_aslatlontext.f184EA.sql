create function st_aslatlontext(geom geometry, tmpl text DEFAULT ''::text
                               ) returns text
    language c
as
$$
LWGEOM_to_latlon
$$;


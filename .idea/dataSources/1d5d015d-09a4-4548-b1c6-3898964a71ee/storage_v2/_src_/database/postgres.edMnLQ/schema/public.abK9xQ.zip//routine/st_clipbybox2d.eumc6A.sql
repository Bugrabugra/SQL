create function st_clipbybox2d(geom geometry, box box2d
                              ) returns geometry
    language c
as
$$
ST_ClipByBox2d
$$;

comment on function st_clipbybox2d(geometry, box2d) is 'args: geom, box - Returns the portion of a geometry falling within a rectangle.';


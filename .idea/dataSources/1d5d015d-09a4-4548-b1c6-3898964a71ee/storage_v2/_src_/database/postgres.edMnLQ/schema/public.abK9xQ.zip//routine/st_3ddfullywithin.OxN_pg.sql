create function st_3ddfullywithin(geom1 geometry, geom2 geometry, double precision
                                 ) returns boolean
    language c
as
$$
LWGEOM_dfullywithin3d
$$;


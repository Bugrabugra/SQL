create function overlaps_nd(geometry, gidx
                           ) returns boolean
    language sql
as
$$
SELECT $2 OPERATOR(public.&&&) $1;
$$;


create function st_azimuth(geom1 geometry, geom2 geometry
                          ) returns double precision
    language c
as
$$
LWGEOM_azimuth
$$;

comment on function st_azimuth(geography, geography) is 'args: pointA, pointB - Returns the north-based azimuth as the angle in radians measured clockwise from the vertical on pointA to pointB.';


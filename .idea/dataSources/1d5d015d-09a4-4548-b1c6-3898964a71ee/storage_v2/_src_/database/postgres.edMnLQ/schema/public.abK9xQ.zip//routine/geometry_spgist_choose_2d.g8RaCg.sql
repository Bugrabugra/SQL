create function geometry_spgist_choose_2d(internal, internal
                                         ) returns void
    language c
as
$$
gserialized_spgist_choose_2d
$$;


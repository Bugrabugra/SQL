create function st_convexhull(geometry
                             ) returns geometry
    language c
as
$$
convexhull
$$;

comment on function st_convexhull(geometry) is 'args: geomA - Computes the convex hull of a geometry.';


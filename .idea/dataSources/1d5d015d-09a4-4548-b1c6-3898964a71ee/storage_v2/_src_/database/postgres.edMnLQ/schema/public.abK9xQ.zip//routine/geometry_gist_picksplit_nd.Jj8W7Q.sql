create function geometry_gist_picksplit_nd(internal, internal
                                          ) returns internal
    language c
as
$$
gserialized_gist_picksplit
$$;


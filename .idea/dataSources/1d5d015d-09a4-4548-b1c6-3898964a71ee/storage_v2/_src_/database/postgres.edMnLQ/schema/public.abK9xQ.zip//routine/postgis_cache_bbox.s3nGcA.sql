create function postgis_cache_bbox(
                                  ) returns trigger
    language c
as
$$
cache_bbox
$$;


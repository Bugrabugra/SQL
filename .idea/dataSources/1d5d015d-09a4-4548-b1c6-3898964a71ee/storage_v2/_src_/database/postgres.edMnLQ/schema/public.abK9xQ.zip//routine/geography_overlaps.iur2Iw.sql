create function geography_overlaps(geography, geography
                                  ) returns boolean
    language c
as
$$
gserialized_overlaps
$$;


create function "_st_touches"(geom1 geometry, geom2 geometry
                             ) returns boolean
    language c
as
$$
touches
$$;


create function "_st_geomfromgml"(text, integer
                                 ) returns geometry
    language c
as
$$
geom_from_gml
$$;


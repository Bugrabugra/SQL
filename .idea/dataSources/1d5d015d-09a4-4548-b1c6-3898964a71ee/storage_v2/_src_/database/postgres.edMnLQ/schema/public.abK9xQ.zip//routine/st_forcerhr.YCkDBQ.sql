create function st_forcerhr(geometry
                           ) returns geometry
    language c
as
$$
LWGEOM_force_clockwise_poly
$$;

comment on function st_forcerhr(geometry) is 'args: g - Force the orientation of the vertices in a polygon to follow the Right-Hand-Rule.';


create function st_3dmaxdistance(geom1 geometry, geom2 geometry
                                ) returns double precision
    language c
as
$$
LWGEOM_maxdistance3d
$$;

comment on function st_3dmaxdistance(geometry, geometry) is 'args: g1, g2 - Returns the 3D cartesian maximum distance (based on spatial ref) between two geometries in projected units.';


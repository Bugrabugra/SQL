create function gserialized_gist_sel_2d(internal, oid, internal, integer
                                       ) returns double precision
    language c
as
$$
gserialized_gist_sel_2d
$$;


create function box2d(geometry
                     ) returns box2d
    language c
as
$$
LWGEOM_to_BOX2D
$$;


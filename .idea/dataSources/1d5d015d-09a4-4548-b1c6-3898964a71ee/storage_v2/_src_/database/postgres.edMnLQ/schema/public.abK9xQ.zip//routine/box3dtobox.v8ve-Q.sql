create function box3dtobox(box3d
                          ) returns box
    language c
as
$$
BOX3D_to_BOX
$$;


create function st_asmvt(anyelement
                        ) returns bytea
    language internal
as
$$
aggregate_dummy
$$;


create function pgis_geometry_clusterintersecting_finalfn(internal
                                                         ) returns geometry[]
    language c
as
$$
pgis_geometry_clusterintersecting_finalfn
$$;


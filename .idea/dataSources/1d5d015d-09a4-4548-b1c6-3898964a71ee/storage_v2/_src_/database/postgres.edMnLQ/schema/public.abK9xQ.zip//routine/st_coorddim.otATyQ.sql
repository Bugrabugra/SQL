create function st_coorddim(geometry geometry
                           ) returns smallint
    language c
as
$$
LWGEOM_ndims
$$;

comment on function st_coorddim(geometry) is 'args: geomA - Return the coordinate dimension of a geometry.';


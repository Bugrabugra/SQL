create function geometry_gist_same_nd(geometry, geometry, internal
                                     ) returns internal
    language c
as
$$
gserialized_gist_same
$$;


create function st_expand(box2d, double precision
                         ) returns box2d
    language c
as
$$
BOX2D_expand
$$;

comment on function st_expand(box3d, float8, float8, float8) is 'args: box, dx, dy, dz=0 - Returns a bounding box expanded from another bounding box or a geometry.';


create function st_interpolatepoint(line geometry, point geometry
                                   ) returns double precision
    language c
as
$$
ST_InterpolatePoint
$$;

comment on function st_interpolatepoint(geometry, geometry) is 'args: line, point - Return the value of the measure dimension of a geometry at the point closed to the provided point.';


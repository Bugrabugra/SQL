create function st_astext(geometry
                         ) returns text
    language c
as
$$
LWGEOM_asText
$$;


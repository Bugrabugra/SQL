create function geometry_spgist_config_2d(internal, internal
                                         ) returns void
    language c
as
$$
gserialized_spgist_config_2d
$$;


create function st_forcepolygoncw(geometry
                                 ) returns geometry
    language c
as
$$
LWGEOM_force_clockwise_poly
$$;

comment on function st_forcepolygoncw(geometry) is 'args: geom - Orients all exterior rings clockwise and all interior rings counter-clockwise.';


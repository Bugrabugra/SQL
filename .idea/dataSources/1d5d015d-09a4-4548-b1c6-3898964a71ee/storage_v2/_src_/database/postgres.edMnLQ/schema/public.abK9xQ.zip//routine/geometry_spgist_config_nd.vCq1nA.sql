create function geometry_spgist_config_nd(internal, internal
                                         ) returns void
    language c
as
$$
gserialized_spgist_config_nd
$$;


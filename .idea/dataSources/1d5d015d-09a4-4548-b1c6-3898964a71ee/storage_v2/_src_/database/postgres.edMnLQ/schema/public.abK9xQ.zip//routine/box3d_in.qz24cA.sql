create function box3d_in(cstring
                        ) returns box3d
    language c
as
$$
BOX3D_in
$$;


create function st_asbinary(geometry
                           ) returns bytea
    language c
as
$$
LWGEOM_asBinary
$$;


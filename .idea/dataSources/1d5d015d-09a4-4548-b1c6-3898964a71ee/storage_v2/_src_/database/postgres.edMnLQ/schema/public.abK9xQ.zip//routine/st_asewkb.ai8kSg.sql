create function st_asewkb(geometry
                         ) returns bytea
    language c
as
$$
WKBFromLWGEOM
$$;


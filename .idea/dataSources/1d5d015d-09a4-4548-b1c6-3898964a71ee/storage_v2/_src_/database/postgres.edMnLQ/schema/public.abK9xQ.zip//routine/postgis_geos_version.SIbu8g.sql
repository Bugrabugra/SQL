create function postgis_geos_version(
                                    ) returns text
    language c
as
$$
postgis_geos_version
$$;

comment on function postgis_geos_version() is 'Returns the version number of the GEOS library.';


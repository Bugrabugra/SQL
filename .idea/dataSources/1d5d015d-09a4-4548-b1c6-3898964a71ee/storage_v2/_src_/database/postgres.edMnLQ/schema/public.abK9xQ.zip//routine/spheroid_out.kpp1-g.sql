create function spheroid_out(spheroid
                            ) returns cstring
    language c
as
$$
ellipsoid_out
$$;


create function pgis_geometry_collect_finalfn(internal
                                             ) returns geometry
    language c
as
$$
pgis_geometry_collect_finalfn
$$;


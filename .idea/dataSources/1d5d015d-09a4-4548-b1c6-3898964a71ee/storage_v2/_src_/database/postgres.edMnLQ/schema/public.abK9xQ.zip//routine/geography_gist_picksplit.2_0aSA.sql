create function geography_gist_picksplit(internal, internal
                                        ) returns internal
    language c
as
$$
gserialized_gist_picksplit
$$;


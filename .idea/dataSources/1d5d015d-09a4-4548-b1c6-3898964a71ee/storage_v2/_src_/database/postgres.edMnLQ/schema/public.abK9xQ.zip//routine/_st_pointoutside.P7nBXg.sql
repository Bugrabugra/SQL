create function "_st_pointoutside"(geography
                                  ) returns geography
    language c
as
$$
geography_point_outside
$$;


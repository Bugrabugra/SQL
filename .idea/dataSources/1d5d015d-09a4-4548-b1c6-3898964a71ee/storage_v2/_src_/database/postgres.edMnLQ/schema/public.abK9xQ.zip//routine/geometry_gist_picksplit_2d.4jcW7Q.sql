create function geometry_gist_picksplit_2d(internal, internal
                                          ) returns internal
    language c
as
$$
gserialized_gist_picksplit_2d
$$;


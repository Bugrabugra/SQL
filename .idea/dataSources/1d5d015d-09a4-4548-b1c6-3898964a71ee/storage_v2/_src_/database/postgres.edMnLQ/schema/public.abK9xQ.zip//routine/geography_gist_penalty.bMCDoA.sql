create function geography_gist_penalty(internal, internal, internal
                                      ) returns internal
    language c
as
$$
gserialized_gist_penalty
$$;


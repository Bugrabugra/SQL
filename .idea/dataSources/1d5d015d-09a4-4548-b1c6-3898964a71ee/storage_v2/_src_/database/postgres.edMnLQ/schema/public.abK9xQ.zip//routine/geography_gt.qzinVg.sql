create function geography_gt(geography, geography
                            ) returns boolean
    language c
as
$$
geography_gt
$$;


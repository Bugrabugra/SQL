create function st_collect(geometry
                          ) returns geometry
    language internal
as
$$
aggregate_dummy
$$;

comment on function st_collect(_geometry) is 'args: g1_array - Creates a GeometryCollection or Multi* geometry from a set of geometries.';


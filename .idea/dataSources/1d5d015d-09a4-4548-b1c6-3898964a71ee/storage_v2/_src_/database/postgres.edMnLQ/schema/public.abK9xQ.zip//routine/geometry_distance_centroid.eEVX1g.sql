create function geometry_distance_centroid(geom1 geometry, geom2 geometry
                                          ) returns double precision
    language c
as
$$
ST_Distance
$$;


create function st_closestpointofapproach(geometry, geometry
                                         ) returns double precision
    language c
as
$$
ST_ClosestPointOfApproach
$$;

comment on function st_closestpointofapproach(geometry, geometry) is 'args: track1, track2 - Returns the measure at which points interpolated along two trajectories are closest.';


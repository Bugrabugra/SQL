create function geography_gist_consistent(internal, geography, integer
                                         ) returns boolean
    language c
as
$$
gserialized_gist_consistent
$$;


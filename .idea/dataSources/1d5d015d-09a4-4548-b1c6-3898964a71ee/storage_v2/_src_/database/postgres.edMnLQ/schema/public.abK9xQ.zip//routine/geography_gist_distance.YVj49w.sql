create function geography_gist_distance(internal, geography, integer
                                       ) returns double precision
    language c
as
$$
gserialized_gist_geog_distance
$$;


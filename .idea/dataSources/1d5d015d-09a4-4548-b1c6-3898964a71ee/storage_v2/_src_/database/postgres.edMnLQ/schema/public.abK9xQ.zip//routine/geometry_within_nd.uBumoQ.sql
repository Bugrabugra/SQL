create function geometry_within_nd(geometry, geometry
                                  ) returns boolean
    language c
as
$$
gserialized_within
$$;


create function gidx_out(gidx
                        ) returns cstring
    language c
as
$$
gidx_out
$$;


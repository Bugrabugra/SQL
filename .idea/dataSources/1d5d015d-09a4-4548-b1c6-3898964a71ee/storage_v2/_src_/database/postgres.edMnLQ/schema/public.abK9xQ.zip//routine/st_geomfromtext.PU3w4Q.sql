create function st_geomfromtext(text
                               ) returns geometry
    language c
as
$$
LWGEOM_from_text
$$;


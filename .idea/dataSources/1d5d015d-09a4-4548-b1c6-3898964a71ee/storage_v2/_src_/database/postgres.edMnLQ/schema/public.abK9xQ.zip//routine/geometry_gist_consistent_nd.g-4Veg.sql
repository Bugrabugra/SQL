create function geometry_gist_consistent_nd(internal, geometry, integer
                                           ) returns boolean
    language c
as
$$
gserialized_gist_consistent
$$;


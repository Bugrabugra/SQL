create function st_force2d(geometry
                          ) returns geometry
    language c
as
$$
LWGEOM_force_2d
$$;

comment on function st_force2d(geometry) is 'args: geomA - Force the geometries into a "2-dimensional mode".';


create function path(geometry
                    ) returns path
    language c
as
$$
geometry_to_path
$$;


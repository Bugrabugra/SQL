create function st_asgeojson(text
                            ) returns text
    language sql
as
$$
SELECT public.ST_AsGeoJson($1::public.geometry, 9, 0);
$$;


create function "_st_asgml"(integer, geometry, integer, integer, text, text
                           ) returns text
    language c
as
$$
LWGEOM_asGML
$$;


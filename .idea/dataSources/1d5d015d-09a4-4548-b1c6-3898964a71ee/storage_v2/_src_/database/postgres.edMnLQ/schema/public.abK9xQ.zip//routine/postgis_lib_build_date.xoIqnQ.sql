create function postgis_lib_build_date(
                                      ) returns text
    language c
as
$$
postgis_lib_build_date
$$;

comment on function postgis_lib_build_date() is 'Returns build date of the PostGIS library.';


create function st_3dextent(geometry
                           ) returns box3d
    language internal
as
$$
aggregate_dummy
$$;

comment on function st_3dextent(geometry) is 'args: geomfield - an aggregate function that returns the 3D bounding box that bounds rows of geometries.';


create function pgis_asmvt_transfn(internal, anyelement
                                  ) returns internal
    language c
as
$$
pgis_asmvt_transfn
$$;


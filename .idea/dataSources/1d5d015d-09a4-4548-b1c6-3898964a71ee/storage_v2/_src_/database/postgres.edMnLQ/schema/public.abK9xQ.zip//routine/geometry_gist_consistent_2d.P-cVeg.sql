create function geometry_gist_consistent_2d(internal, geometry, integer
                                           ) returns boolean
    language c
as
$$
gserialized_gist_consistent_2d
$$;


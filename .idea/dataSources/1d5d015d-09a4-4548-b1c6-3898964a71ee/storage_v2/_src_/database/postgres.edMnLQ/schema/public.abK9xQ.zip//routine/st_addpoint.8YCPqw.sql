create function st_addpoint(geom1 geometry, geom2 geometry
                           ) returns geometry
    language c
as
$$
LWGEOM_addpoint
$$;

comment on function st_addpoint(geometry, geometry, int4) is 'args: linestring, point, position - Add a point to a LineString.';


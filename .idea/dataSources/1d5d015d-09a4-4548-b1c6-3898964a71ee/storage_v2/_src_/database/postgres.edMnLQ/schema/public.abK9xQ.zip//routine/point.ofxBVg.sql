create function point(geometry
                     ) returns point
    language c
as
$$
geometry_to_point
$$;


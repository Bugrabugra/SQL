create function geometry_overlaps_nd(geometry, geometry
                                    ) returns boolean
    language c
as
$$
gserialized_overlaps
$$;


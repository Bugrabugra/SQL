create function "_postgis_scripts_pgsql_version"(
                                                ) returns text
    language sql
as
$$
SELECT '120'::text AS version
$$;


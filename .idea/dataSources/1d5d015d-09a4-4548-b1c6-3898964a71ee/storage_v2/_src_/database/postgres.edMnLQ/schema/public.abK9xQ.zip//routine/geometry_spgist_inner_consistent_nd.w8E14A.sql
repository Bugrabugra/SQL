create function geometry_spgist_inner_consistent_nd(internal, internal
                                                   ) returns void
    language c
as
$$
gserialized_spgist_inner_consistent_nd
$$;


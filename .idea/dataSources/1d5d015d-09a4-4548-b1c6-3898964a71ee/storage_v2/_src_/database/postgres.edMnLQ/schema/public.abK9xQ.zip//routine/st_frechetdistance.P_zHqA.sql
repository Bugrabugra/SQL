create function st_frechetdistance(geom1 geometry, geom2 geometry, double precision DEFAULT '-1'::integer
                                  ) returns double precision
    language c
as
$$
ST_FrechetDistance
$$;

comment on function st_frechetdistance(geometry, geometry, float8) is 'args: g1, g2, densifyFrac = -1 - Returns the Fréchet distance between two geometries.';


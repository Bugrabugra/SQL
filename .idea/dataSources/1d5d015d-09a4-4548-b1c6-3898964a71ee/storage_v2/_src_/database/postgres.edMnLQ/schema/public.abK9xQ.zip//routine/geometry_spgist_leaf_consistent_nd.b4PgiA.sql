create function geometry_spgist_leaf_consistent_nd(internal, internal
                                                  ) returns boolean
    language c
as
$$
gserialized_spgist_leaf_consistent_nd
$$;


create function st_cpawithin(geometry, geometry, double precision
                            ) returns boolean
    language c
as
$$
ST_CPAWithin
$$;

comment on function st_cpawithin(geometry, geometry, float8) is 'args: track1, track2, maxdist - Returns true if the closest point of approach of two trajectoriesis within the specified distance.';


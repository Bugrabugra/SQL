create function geometry_spgist_compress_3d(internal
                                           ) returns internal
    language c
as
$$
gserialized_spgist_compress_3d
$$;


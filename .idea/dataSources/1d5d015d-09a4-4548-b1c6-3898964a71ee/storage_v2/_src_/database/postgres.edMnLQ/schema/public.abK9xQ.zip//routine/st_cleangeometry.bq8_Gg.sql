create function st_cleangeometry(geometry
                                ) returns geometry
    language c
as
$$
ST_CleanGeometry
$$;


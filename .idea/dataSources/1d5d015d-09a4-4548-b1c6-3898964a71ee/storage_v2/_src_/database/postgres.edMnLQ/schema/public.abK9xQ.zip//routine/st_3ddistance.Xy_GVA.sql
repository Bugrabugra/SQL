create function st_3ddistance(geom1 geometry, geom2 geometry
                             ) returns double precision
    language c
as
$$
ST_3DDistance
$$;

comment on function st_3ddistance(geometry, geometry) is 'args: g1, g2 - Returns the 3D cartesian minimum distance (based on spatial ref) between two geometries in projected units.';


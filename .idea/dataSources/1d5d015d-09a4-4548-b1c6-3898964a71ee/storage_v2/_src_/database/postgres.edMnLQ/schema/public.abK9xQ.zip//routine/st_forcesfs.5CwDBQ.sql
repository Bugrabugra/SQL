create function st_forcesfs(geometry
                           ) returns geometry
    language c
as
$$
LWGEOM_force_sfs
$$;

comment on function st_forcesfs(geometry) is 'args: geomA - Force the geometries to use SFS 1.1 geometry types only.';


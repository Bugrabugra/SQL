create function geography_spgist_picksplit_nd(internal, internal
                                             ) returns void
    language c
as
$$
gserialized_spgist_picksplit_nd
$$;


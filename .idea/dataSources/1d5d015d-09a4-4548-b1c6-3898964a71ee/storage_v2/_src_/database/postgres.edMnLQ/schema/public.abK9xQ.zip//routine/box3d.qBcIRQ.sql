create function box3d(geometry
                     ) returns box3d
    language c
as
$$
LWGEOM_to_BOX3D
$$;


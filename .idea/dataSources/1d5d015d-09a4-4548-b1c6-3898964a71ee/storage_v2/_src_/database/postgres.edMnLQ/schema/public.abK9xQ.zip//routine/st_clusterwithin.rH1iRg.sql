create function st_clusterwithin(geometry, double precision
                                ) returns geometry[]
    language internal
as
$$
aggregate_dummy
$$;

comment on function st_clusterwithin(geometry, float8) is 'args: g, distance - Aggregate function that clusters the input geometries by separation distance.';


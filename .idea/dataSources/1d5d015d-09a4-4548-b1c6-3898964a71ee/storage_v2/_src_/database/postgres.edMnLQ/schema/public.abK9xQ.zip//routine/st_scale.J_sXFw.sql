create function st_scale(geometry, geometry
                        ) returns geometry
    language c
as
$$
ST_Scale
$$;

comment on function st_scale(geometry, geometry) is 'args: geom, factor, origin - Scales a geometry by given factors.';


create function geography_cmp(geography, geography
                             ) returns integer
    language c
as
$$
geography_cmp
$$;


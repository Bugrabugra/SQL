create function st_geomfromkml(text
                              ) returns geometry
    language c
as
$$
geom_from_kml
$$;


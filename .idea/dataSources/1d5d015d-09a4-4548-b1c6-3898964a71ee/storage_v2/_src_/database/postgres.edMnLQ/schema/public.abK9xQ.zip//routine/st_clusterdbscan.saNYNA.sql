create function st_clusterdbscan(geometry, eps double precision, minpoints integer
                                ) returns integer
    language c
as
$$
ST_ClusterDBSCAN
$$;

comment on function st_clusterdbscan(geometry, float8, int4) is 'args: geom, eps, minpoints - Window function that returns a cluster id for each input geometry using the DBSCAN algorithm.';


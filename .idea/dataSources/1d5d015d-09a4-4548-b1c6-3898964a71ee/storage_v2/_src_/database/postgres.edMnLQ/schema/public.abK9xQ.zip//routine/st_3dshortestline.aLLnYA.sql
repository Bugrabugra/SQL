create function st_3dshortestline(geom1 geometry, geom2 geometry
                                 ) returns geometry
    language c
as
$$
LWGEOM_shortestline3d
$$;

comment on function st_3dshortestline(geometry, geometry) is 'args: g1, g2 - Returns the 3D shortest line between two geometries';


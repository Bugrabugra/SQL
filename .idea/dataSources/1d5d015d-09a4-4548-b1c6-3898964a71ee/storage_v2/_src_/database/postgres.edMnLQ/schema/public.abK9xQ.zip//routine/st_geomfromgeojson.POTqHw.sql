create function st_geomfromgeojson(text
                                  ) returns geometry
    language c
as
$$
geom_from_geojson
$$;


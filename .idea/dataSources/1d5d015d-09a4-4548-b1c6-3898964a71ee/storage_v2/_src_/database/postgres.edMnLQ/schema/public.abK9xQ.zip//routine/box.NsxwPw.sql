create function box(geometry
                   ) returns box
    language c
as
$$
LWGEOM_to_BOX
$$;


create function st_expand(box2d, double precision
                         ) returns box2d
    language c
as
$$
BOX2D_expand
$$;

comment on function st_expand(geometry, float8) is 'args: geom, units_to_expand - Returns a bounding box expanded from another bounding box or a geometry.';


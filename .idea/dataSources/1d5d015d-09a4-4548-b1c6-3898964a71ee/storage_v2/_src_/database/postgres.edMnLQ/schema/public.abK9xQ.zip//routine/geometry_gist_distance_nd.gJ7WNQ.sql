create function geometry_gist_distance_nd(internal, geometry, integer
                                         ) returns double precision
    language c
as
$$
gserialized_gist_distance
$$;


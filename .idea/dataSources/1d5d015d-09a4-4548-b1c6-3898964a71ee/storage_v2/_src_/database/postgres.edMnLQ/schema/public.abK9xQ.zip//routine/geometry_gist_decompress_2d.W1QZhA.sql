create function geometry_gist_decompress_2d(internal
                                           ) returns internal
    language c
as
$$
gserialized_gist_decompress_2d
$$;


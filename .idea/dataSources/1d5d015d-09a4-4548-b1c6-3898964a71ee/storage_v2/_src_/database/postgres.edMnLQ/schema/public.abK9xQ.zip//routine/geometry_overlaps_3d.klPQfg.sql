create function geometry_overlaps_3d(geom1 geometry, geom2 geometry
                                    ) returns boolean
    language c
as
$$
gserialized_overlaps_3d
$$;


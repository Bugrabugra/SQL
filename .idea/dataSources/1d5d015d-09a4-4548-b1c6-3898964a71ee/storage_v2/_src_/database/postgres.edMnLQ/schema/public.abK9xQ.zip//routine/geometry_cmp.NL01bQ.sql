create function geometry_cmp(geom1 geometry, geom2 geometry
                            ) returns integer
    language c
as
$$
lwgeom_cmp
$$;


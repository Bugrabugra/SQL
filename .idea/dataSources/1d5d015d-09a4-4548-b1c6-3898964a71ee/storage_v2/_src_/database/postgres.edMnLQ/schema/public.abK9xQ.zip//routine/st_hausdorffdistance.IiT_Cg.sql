create function st_hausdorffdistance(geom1 geometry, geom2 geometry
                                    ) returns double precision
    language c
as
$$
hausdorffdistance
$$;

comment on function st_hausdorffdistance(geometry, geometry) is 'args: g1, g2 - Returns the Hausdorff distance between two geometries.';


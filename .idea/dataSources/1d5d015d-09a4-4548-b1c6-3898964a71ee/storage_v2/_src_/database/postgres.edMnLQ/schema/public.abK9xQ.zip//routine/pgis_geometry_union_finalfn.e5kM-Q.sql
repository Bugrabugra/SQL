create function pgis_geometry_union_finalfn(internal
                                           ) returns geometry
    language c
as
$$
pgis_geometry_union_finalfn
$$;


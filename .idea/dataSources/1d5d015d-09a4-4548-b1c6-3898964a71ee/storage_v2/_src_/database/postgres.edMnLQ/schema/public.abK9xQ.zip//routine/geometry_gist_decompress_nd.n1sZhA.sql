create function geometry_gist_decompress_nd(internal
                                           ) returns internal
    language c
as
$$
gserialized_gist_decompress
$$;


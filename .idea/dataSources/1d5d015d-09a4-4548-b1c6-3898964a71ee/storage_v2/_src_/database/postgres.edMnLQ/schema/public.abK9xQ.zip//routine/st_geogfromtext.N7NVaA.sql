create function st_geogfromtext(text
                               ) returns geography
    language c
as
$$
geography_from_text
$$;


create function geography_ge(geography, geography
                            ) returns boolean
    language c
as
$$
geography_ge
$$;


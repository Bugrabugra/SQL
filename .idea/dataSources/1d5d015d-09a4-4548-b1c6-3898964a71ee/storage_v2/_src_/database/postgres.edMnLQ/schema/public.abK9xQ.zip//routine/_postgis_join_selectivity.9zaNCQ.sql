create function "_postgis_join_selectivity"(regclass, text, regclass, text, text DEFAULT '2'::text
                                           ) returns double precision
    language c
as
$$
_postgis_gserialized_joinsel
$$;


create function st_buffer(geom geometry, radius double precision, options text DEFAULT ''::text
                         ) returns geometry
    language c
as
$$
buffer
$$;


create function geography_send(geography
                              ) returns bytea
    language c
as
$$
geography_send
$$;


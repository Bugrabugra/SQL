create function st_geomfromwkb(bytea
                              ) returns geometry
    language c
as
$$
LWGEOM_from_WKB
$$;


create function st_estimatedextent(text, text
                                  ) returns box2d
    language c
as
$$
gserialized_estimated_extent
$$;

comment on function st_estimatedextent(text, text, text, bool) is 'args: schema_name, table_name, geocolumn_name, parent_only - Return the estimated extent of a spatial table.';


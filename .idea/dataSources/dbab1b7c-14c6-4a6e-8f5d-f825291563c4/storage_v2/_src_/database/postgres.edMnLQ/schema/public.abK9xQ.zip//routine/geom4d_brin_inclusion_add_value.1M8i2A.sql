create function geom4d_brin_inclusion_add_value(internal, internal, internal, internal
                                               ) returns boolean
    language c
as
$$
geom4d_brin_inclusion_add_value
$$;


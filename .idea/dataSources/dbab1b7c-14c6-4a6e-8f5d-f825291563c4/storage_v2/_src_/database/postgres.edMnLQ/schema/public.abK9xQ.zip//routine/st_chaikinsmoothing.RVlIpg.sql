create function st_chaikinsmoothing(geometry, integer DEFAULT 1, boolean DEFAULT false
                                   ) returns geometry
    language c
as
$$
LWGEOM_ChaikinSmoothing
$$;

comment on function st_chaikinsmoothing(geometry, int4, bool) is 'args: geom, nIterations = 1, preserveEndPoints = false - Returns a "smoothed" version of the given geometry using the Chaikin algorithm';


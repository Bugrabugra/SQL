create function st_area(text
                       ) returns double precision
    language sql
as
$$
SELECT public.ST_Area($1::public.geometry);
$$;

comment on function st_area(geometry) is 'args: g1 - Returns the area of a polygonal geometry.';


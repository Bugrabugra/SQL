create function geometrytype(geometry
                            ) returns text
    language c
as
$$
LWGEOM_getTYPE
$$;


create function postgis_index_supportfn(internal
                                       ) returns internal
    language c
as
$$
postgis_index_supportfn
$$;


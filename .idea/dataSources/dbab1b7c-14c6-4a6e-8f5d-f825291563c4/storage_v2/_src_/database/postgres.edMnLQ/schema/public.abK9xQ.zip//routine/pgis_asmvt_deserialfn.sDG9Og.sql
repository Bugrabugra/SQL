create function pgis_asmvt_deserialfn(bytea, internal
                                     ) returns internal
    language c
as
$$
pgis_asmvt_deserialfn
$$;


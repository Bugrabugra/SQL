create function json(geometry
                    ) returns json
    language c
as
$$
geometry_to_json
$$;


create function st_hausdorffdistance(geom1 geometry, geom2 geometry
                                    ) returns double precision
    language c
as
$$
hausdorffdistance
$$;

comment on function st_hausdorffdistance(geometry, geometry, float8) is 'args: g1, g2, densifyFrac - Returns the Hausdorff distance between two geometries.';


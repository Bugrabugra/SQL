create function postgis_liblwgeom_version(
                                         ) returns text
    language c
as
$$
postgis_liblwgeom_version
$$;

comment on function postgis_liblwgeom_version() is 'Returns the version number of the liblwgeom library. This should match the version of PostGIS.';


create function "_st_coveredby"(geom1 geometry, geom2 geometry
                               ) returns boolean
    language c
as
$$
coveredby
$$;


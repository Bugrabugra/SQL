create function geometry_gt(geom1 geometry, geom2 geometry
                           ) returns boolean
    language c
as
$$
lwgeom_gt
$$;


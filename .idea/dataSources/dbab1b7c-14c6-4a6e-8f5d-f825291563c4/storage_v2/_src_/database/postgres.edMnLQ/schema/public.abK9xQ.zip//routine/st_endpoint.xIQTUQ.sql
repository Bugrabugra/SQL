create function st_endpoint(geometry
                           ) returns geometry
    language c
as
$$
LWGEOM_endpoint_linestring
$$;

comment on function st_endpoint(geometry) is 'args: g - Returns the last point of a LineString or CircularLineString.';


create function geography_gist_union(bytea, internal
                                    ) returns internal
    language c
as
$$
gserialized_gist_union
$$;


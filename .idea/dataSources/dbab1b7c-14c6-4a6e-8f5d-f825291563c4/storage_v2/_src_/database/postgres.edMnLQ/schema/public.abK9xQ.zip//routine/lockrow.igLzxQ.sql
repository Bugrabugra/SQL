create function lockrow(text, text, text
                       ) returns integer
    language sql
as
$$
SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00');
$$;


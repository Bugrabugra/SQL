create function geometry(geometry, integer, boolean
                        ) returns geometry
    language c
as
$$
geometry_enforce_typmod
$$;


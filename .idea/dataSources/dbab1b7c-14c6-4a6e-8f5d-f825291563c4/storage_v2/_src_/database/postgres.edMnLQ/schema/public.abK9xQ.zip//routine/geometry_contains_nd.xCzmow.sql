create function geometry_contains_nd(geometry, geometry
                                    ) returns boolean
    language c
as
$$
gserialized_contains
$$;


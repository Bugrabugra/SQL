create function jsonb(geometry
                     ) returns jsonb
    language c
as
$$
geometry_to_jsonb
$$;


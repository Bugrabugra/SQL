create function st_buildarea(geometry
                            ) returns geometry
    language c
as
$$
ST_BuildArea
$$;

comment on function st_buildarea(geometry) is 'args: A - Creates an areal geometry formed by the constituent linework of given geometry';


create function st_distance(text, text
                           ) returns double precision
    language sql
as
$$
SELECT public.ST_Distance($1::public.geometry, $2::public.geometry);
$$;

comment on function st_distance(geometry, geometry) is 'args: g1, g2 - Returns the distance between two geometry or geography values.';


create function geometry_overlaps(geom1 geometry, geom2 geometry
                                 ) returns boolean
    language c
as
$$
gserialized_overlaps_2d
$$;


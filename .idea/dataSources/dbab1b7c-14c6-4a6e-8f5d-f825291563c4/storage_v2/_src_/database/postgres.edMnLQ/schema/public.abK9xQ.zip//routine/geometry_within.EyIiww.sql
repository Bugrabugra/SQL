create function geometry_within(geom1 geometry, geom2 geometry
                               ) returns boolean
    language c
as
$$
gserialized_within_2d
$$;


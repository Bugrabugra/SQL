create function "_st_equals"(geom1 geometry, geom2 geometry
                            ) returns boolean
    language c
as
$$
ST_Equals
$$;


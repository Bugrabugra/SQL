create function postgis_proj_version(
                                    ) returns text
    language c
as
$$
postgis_proj_version
$$;

comment on function postgis_proj_version() is 'Returns the version number of the PROJ4 library.';


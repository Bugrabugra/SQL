create function geometry_send(geometry
                             ) returns bytea
    language c
as
$$
LWGEOM_send
$$;


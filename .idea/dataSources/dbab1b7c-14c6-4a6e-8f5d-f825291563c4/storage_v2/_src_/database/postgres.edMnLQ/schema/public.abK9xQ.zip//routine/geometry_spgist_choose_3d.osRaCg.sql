create function geometry_spgist_choose_3d(internal, internal
                                         ) returns void
    language c
as
$$
gserialized_spgist_choose_3d
$$;


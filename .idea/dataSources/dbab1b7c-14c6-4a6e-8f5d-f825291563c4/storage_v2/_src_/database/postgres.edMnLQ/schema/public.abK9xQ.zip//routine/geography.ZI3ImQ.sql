create function geography(bytea
                         ) returns geography
    language c
as
$$
geography_from_binary
$$;


create function geog_brin_inclusion_add_value(internal, internal, internal, internal
                                             ) returns boolean
    language c
as
$$
geog_brin_inclusion_add_value
$$;


create function dropgeometrytable(table_name character varying
                                 ) returns text
    language sql
as
$$
SELECT public.DropGeometryTable('','',$1)
$$;

comment on function dropgeometrytable(varchar, varchar, varchar) is 'args: catalog_name, schema_name, table_name - Drops a table and all its references in geometry_columns.';


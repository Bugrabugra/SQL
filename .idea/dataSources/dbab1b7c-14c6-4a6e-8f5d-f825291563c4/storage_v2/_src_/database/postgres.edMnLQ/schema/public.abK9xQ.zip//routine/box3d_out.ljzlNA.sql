create function box3d_out(box3d
                         ) returns cstring
    language c
as
$$
BOX3D_out
$$;


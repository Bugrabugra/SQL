create function st_asmvtgeom(geom geometry, bounds box2d, extent integer DEFAULT 4096, buffer integer DEFAULT 256, clip_geom boolean DEFAULT true
                            ) returns geometry
    language c
as
$$
ST_AsMVTGeom
$$;


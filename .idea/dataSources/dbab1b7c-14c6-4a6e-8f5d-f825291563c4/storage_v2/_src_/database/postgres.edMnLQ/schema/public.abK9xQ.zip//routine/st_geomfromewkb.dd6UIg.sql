create function st_geomfromewkb(bytea
                               ) returns geometry
    language c
as
$$
LWGEOMFromEWKB
$$;


create function postgis_geos_noop(geometry
                                 ) returns geometry
    language c
as
$$
GEOSnoop
$$;


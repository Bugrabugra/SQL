create function "_st_bestsrid"(geography
                              ) returns integer
    language c
as
$$
geography_bestsrid
$$;


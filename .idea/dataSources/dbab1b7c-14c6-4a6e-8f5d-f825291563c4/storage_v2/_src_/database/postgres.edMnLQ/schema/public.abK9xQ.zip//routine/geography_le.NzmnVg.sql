create function geography_le(geography, geography
                            ) returns boolean
    language c
as
$$
geography_le
$$;


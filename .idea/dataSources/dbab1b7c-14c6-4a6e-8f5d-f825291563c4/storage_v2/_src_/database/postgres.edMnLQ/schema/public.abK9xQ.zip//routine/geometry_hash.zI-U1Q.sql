create function geometry_hash(geometry
                             ) returns integer
    language c
as
$$
lwgeom_hash
$$;


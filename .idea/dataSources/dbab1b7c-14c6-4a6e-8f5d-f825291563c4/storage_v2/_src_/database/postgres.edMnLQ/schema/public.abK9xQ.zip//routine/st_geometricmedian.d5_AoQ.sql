create function st_geometricmedian(g geometry, tolerance double precision DEFAULT NULL::double precision, max_iter integer DEFAULT 10000, fail_if_not_converged boolean DEFAULT false
                                  ) returns geometry
    language c
as
$$
ST_GeometricMedian
$$;

comment on function st_geometricmedian(geometry, float8, int4, bool) is 'args: 
					g
				, 
					tolerance
				, 
					max_iter
				, 
					fail_if_not_converged
				 - Returns the geometric median of a MultiPoint.';


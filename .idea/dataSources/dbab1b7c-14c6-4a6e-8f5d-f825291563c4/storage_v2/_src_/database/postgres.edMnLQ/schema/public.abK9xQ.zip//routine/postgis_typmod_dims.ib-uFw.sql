create function postgis_typmod_dims(integer
                                   ) returns integer
    language c
as
$$
postgis_typmod_dims
$$;


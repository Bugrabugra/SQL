create function geometry_spgist_compress_nd(internal
                                           ) returns internal
    language c
as
$$
gserialized_spgist_compress_nd
$$;


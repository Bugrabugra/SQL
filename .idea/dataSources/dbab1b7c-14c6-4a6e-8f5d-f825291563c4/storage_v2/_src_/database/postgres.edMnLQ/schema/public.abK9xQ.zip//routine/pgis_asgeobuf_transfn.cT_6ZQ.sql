create function pgis_asgeobuf_transfn(internal, anyelement
                                     ) returns internal
    language c
as
$$
pgis_asgeobuf_transfn
$$;


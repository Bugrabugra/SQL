create function st_intersection(text, text
                               ) returns geometry
    language sql
as
$$
SELECT public.ST_Intersection($1::public.geometry, $2::public.geometry);
$$;


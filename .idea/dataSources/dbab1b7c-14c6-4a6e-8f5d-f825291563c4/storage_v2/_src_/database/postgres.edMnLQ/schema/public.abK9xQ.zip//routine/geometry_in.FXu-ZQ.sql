create function geometry_in(cstring
                           ) returns geometry
    language c
as
$$
LWGEOM_in
$$;


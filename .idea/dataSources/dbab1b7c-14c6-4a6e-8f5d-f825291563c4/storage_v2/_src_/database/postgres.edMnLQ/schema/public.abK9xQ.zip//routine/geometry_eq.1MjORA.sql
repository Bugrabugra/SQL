create function geometry_eq(geom1 geometry, geom2 geometry
                           ) returns boolean
    language c
as
$$
lwgeom_eq
$$;


create function st_interiorringn(geometry, integer
                                ) returns geometry
    language c
as
$$
LWGEOM_interiorringn_polygon
$$;

comment on function st_interiorringn(geometry, int4) is 'args: a_polygon, n - Returns the Nth interior ring (hole) of a Polygon.';


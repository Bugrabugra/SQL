create function box3d(geometry
                     ) returns box3d
    language c
as
$$
LWGEOM_to_BOX3D
$$;

comment on function box3d(geometry) is 'args: geomA - Returns a BOX3D representing the 3D extent of the geometry.';


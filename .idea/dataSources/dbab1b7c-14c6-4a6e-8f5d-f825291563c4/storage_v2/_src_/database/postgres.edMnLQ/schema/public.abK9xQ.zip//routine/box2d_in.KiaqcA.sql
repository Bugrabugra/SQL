create function box2d_in(cstring
                        ) returns box2d
    language c
as
$$
BOX2D_in
$$;


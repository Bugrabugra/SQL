create function st_difference(geom1 geometry, geom2 geometry
                             ) returns geometry
    language c
as
$$
ST_Difference
$$;

comment on function st_difference(geometry, geometry) is 'args: geomA, geomB - Returns a geometry that represents that part of geometry A that does not intersect with geometry B.';


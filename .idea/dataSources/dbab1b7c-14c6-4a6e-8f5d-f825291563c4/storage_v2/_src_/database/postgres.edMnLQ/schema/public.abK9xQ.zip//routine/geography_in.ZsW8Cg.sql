create function geography_in(cstring, oid, integer
                            ) returns geography
    language c
as
$$
geography_in
$$;


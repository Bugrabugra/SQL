create function st_geomfromewkt(text
                               ) returns geometry
    language c
as
$$
parse_WKT_lwgeom
$$;


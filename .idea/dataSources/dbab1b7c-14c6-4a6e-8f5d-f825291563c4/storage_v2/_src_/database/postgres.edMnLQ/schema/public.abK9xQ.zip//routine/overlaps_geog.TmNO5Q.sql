create function overlaps_geog(gidx, gidx
                             ) returns boolean
    language c
as
$$
gserialized_gidx_gidx_overlaps
$$;


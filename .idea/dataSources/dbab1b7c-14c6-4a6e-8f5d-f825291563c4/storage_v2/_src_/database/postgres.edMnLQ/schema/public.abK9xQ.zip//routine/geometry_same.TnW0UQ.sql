create function geometry_same(geom1 geometry, geom2 geometry
                             ) returns boolean
    language c
as
$$
gserialized_same_2d
$$;


create function st_area2d(geometry
                         ) returns double precision
    language c
as
$$
ST_Area
$$;


create function st_asgeobuf(anyelement
                           ) returns bytea
    language internal
as
$$
aggregate_dummy
$$;


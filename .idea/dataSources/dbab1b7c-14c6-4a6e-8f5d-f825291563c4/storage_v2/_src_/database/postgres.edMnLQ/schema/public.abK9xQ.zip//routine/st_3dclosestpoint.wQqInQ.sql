create function st_3dclosestpoint(geom1 geometry, geom2 geometry
                                 ) returns geometry
    language c
as
$$
LWGEOM_closestpoint3d
$$;

comment on function st_3dclosestpoint(geometry, geometry) is 'args: g1, g2 - Returns the 3D point on g1 that is closest to g2. This is the first point of the 3D shortest line.';


create function st_3dlongestline(geom1 geometry, geom2 geometry
                                ) returns geometry
    language c
as
$$
LWGEOM_longestline3d
$$;

comment on function st_3dlongestline(geometry, geometry) is 'args: g1, g2 - Returns the 3D longest line between two geometries';


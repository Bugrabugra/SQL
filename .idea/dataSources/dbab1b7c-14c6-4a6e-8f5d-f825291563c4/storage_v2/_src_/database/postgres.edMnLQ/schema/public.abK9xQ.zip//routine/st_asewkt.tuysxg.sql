create function st_asewkt(text
                         ) returns text
    language sql
as
$$
SELECT public.ST_AsEWKT($1::public.geometry);
$$;


create function geometry_same_3d(geom1 geometry, geom2 geometry
                                ) returns boolean
    language c
as
$$
gserialized_same_3d
$$;


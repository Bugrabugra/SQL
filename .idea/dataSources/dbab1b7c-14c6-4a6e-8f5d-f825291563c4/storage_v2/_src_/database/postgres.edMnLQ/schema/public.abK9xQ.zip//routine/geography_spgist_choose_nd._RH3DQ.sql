create function geography_spgist_choose_nd(internal, internal
                                          ) returns void
    language c
as
$$
gserialized_spgist_choose_nd
$$;


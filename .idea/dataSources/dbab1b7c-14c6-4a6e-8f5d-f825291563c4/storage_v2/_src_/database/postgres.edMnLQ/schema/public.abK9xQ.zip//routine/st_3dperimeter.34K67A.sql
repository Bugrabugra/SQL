create function st_3dperimeter(geometry
                              ) returns double precision
    language c
as
$$
LWGEOM_perimeter_poly
$$;

comment on function st_3dperimeter(geometry) is 'args: geomA - Returns the 3D perimeter of a polygonal geometry.';


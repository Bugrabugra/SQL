create function st_force4d(geometry
                          ) returns geometry
    language c
as
$$
LWGEOM_force_4d
$$;

comment on function st_force4d(geometry) is 'args: geomA - Force the geometries into XYZM mode.';


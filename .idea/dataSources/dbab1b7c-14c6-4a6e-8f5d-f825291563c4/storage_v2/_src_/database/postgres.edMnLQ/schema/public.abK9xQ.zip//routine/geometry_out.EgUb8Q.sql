create function geometry_out(geometry
                            ) returns cstring
    language c
as
$$
LWGEOM_out
$$;


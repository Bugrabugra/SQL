create function geometry_spgist_picksplit_3d(internal, internal
                                            ) returns void
    language c
as
$$
gserialized_spgist_picksplit_3d
$$;


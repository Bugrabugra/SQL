create function pgis_geometry_accum_transfn(internal, geometry
                                           ) returns internal
    language c
as
$$
pgis_geometry_accum_transfn
$$;


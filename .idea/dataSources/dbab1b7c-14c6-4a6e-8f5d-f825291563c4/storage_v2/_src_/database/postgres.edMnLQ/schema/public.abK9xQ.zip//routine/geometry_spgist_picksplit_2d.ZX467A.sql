create function geometry_spgist_picksplit_2d(internal, internal
                                            ) returns void
    language c
as
$$
gserialized_spgist_picksplit_2d
$$;


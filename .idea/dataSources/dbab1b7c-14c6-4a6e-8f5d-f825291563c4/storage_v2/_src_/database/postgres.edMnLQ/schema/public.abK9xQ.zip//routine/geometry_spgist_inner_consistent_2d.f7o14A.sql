create function geometry_spgist_inner_consistent_2d(internal, internal
                                                   ) returns void
    language c
as
$$
gserialized_spgist_inner_consistent_2d
$$;


create function st_buffer(geom geometry, radius double precision, options text DEFAULT ''::text
                         ) returns geometry
    language c
as
$$
buffer
$$;

comment on function st_buffer(geography, float8, text) is 'args: g1, radius_of_buffer, buffer_style_parameters - (T)Returns a geometry covering all points within a given distancefrom the input geometry.';


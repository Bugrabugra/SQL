create function st_curvetoline(geom geometry, tol double precision DEFAULT 32, toltype integer DEFAULT 0, flags integer DEFAULT 0
                              ) returns geometry
    language c
as
$$
ST_CurveToLine
$$;

comment on function st_curvetoline(geometry, float8, int4, int4) is 'args: curveGeom, tolerance, tolerance_type, flags - Converts a CIRCULARSTRING/CURVEPOLYGON/MULTISURFACE to a LINESTRING/POLYGON/MULTIPOLYGON';


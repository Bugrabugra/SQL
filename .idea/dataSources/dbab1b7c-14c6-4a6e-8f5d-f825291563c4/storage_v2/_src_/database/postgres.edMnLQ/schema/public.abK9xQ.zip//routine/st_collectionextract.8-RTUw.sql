create function st_collectionextract(geometry, integer
                                    ) returns geometry
    language c
as
$$
ST_CollectionExtract
$$;

comment on function st_collectionextract(geometry, int4) is 'args: collection, type - Given a (multi)geometry, return a (multi)geometry consisting only of elements of the specified type.';


create function st_3dlineinterpolatepoint(geometry, double precision
                                         ) returns geometry
    language c
as
$$
ST_3DLineInterpolatePoint
$$;


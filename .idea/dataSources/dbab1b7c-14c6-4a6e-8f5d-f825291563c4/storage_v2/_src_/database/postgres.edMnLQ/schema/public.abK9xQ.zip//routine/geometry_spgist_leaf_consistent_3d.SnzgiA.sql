create function geometry_spgist_leaf_consistent_3d(internal, internal
                                                  ) returns boolean
    language c
as
$$
gserialized_spgist_leaf_consistent_3d
$$;


create function st_geographyfromtext(text
                                    ) returns geography
    language c
as
$$
geography_from_text
$$;


create function postgis_addbbox(geometry
                               ) returns geometry
    language c
as
$$
LWGEOM_addBBOX
$$;

comment on function postgis_addbbox(geometry) is 'args: geomA - Add bounding box to the geometry.';


create function st_forcecurve(geometry
                             ) returns geometry
    language c
as
$$
LWGEOM_force_curve
$$;

comment on function st_forcecurve(geometry) is 'args: g - Upcast a geometry into its curved type, if applicable.';


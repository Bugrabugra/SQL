create function "_st_asx3d"(integer, geometry, integer, integer, text
                           ) returns text
    language c
as
$$
LWGEOM_asX3D
$$;


create function st_dump(geometry
                       ) returns SETOF geometry_dump
    language c
as
$$
LWGEOM_dump
$$;

comment on function st_dump(geometry) is 'args: g1 - Returns a set of geometry_dump rows for the components of a geometry.';


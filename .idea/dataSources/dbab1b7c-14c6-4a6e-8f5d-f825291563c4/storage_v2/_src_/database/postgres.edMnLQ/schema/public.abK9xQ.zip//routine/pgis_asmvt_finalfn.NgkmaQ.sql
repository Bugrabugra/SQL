create function pgis_asmvt_finalfn(internal
                                  ) returns bytea
    language c
as
$$
pgis_asmvt_finalfn
$$;


create function st_3dlength(geometry
                           ) returns double precision
    language c
as
$$
LWGEOM_length_linestring
$$;

comment on function st_3dlength(geometry) is 'args: a_3dlinestring - Returns the 3D length of a linear geometry.';


create function st_expand(box2d, double precision
                         ) returns box2d
    language c
as
$$
BOX2D_expand
$$;

comment on function st_expand(box2d, float8) is 'args: box, units_to_expand - Returns a bounding box expanded from another bounding box or a geometry.';


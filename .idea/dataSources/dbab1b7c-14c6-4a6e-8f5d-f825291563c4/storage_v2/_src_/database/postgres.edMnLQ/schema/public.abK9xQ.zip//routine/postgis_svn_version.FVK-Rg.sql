create function postgis_svn_version(
                                   ) returns text
    language c
as
$$
postgis_svn_version
$$;


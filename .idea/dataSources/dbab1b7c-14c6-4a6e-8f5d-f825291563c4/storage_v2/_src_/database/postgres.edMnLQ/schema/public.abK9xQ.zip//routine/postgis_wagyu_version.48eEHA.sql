create function postgis_wagyu_version(
                                     ) returns text
    language c
as
$$
postgis_wagyu_version
$$;

comment on function postgis_wagyu_version() is 'Returns the version number of the internal Wagyu library.';


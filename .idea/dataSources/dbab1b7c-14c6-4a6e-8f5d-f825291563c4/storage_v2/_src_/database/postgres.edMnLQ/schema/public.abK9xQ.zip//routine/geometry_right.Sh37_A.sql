create function geometry_right(geom1 geometry, geom2 geometry
                              ) returns boolean
    language c
as
$$
gserialized_right_2d
$$;


create function polygon(geometry
                       ) returns polygon
    language c
as
$$
geometry_to_polygon
$$;


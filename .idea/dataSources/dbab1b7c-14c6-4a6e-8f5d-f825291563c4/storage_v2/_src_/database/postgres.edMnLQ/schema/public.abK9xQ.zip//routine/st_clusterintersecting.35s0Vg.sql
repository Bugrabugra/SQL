create function st_clusterintersecting(geometry
                                      ) returns geometry[]
    language internal
as
$$
aggregate_dummy
$$;


create function checkauthtrigger(
                                ) returns trigger
    language c
as
$$
check_authorization
$$;


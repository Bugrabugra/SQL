create function geography_lt(geography, geography
                            ) returns boolean
    language c
as
$$
geography_lt
$$;


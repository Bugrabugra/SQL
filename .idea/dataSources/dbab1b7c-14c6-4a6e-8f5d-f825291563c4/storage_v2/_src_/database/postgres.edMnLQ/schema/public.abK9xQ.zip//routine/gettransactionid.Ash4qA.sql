create function gettransactionid(
                                ) returns xid
    language c
as
$$
getTransactionID
$$;


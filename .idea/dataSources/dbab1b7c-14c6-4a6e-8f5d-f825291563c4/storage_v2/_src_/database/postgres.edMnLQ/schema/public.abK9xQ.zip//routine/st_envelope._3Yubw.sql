create function st_envelope(geometry
                           ) returns geometry
    language c
as
$$
LWGEOM_envelope
$$;

comment on function st_envelope(geometry) is 'args: g1 - Returns a geometry representing the bounding box of a geometry.';


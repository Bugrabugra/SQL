create function st_dumprings(geometry
                            ) returns SETOF geometry_dump
    language c
as
$$
LWGEOM_dump_rings
$$;

comment on function st_dumprings(geometry) is 'args: a_polygon - Returns a set of geometry_dump rows for the exterior and interior rings of a Polygon.';


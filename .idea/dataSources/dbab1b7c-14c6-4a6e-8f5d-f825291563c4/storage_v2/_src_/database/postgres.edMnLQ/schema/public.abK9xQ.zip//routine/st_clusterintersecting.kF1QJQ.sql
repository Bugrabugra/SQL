create function st_clusterintersecting(geometry
                                      ) returns geometry[]
    language internal
as
$$
aggregate_dummy
$$;

comment on function st_clusterintersecting(geometry) is 'args: g - Aggregate function that clusters the input geometries into connected sets.';


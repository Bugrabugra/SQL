create function geometry_distance_box(geom1 geometry, geom2 geometry
                                     ) returns double precision
    language c
as
$$
gserialized_distance_box_2d
$$;


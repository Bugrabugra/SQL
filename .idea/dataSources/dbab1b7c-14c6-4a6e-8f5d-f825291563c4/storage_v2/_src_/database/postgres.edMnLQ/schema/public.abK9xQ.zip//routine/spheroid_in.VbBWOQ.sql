create function spheroid_in(cstring
                           ) returns spheroid
    language c
as
$$
ellipsoid_in
$$;


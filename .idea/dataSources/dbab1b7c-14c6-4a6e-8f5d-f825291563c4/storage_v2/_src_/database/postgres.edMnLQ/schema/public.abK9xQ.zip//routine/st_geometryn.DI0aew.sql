create function st_geometryn(geometry, integer
                            ) returns geometry
    language c
as
$$
LWGEOM_geometryn_collection
$$;

comment on function st_geometryn(geometry, int4) is 'args: geomA, n - Return the Nth geometry element of a geometry collection.';


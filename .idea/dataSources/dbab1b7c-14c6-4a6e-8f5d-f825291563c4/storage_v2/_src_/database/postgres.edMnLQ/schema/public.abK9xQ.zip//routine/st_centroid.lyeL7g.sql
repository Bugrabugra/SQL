create function st_centroid(text
                           ) returns geometry
    language sql
as
$$
SELECT public.ST_Centroid($1::public.geometry);
$$;

comment on function st_centroid(geography, bool) is 'args: g1, use_spheroid=true - Returns the geometric center of a geometry.';


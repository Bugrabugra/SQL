create function st_distancecpa(geometry, geometry
                              ) returns double precision
    language c
as
$$
ST_DistanceCPA
$$;

comment on function st_distancecpa(geometry, geometry) is 'args: track1, track2 - Returns the distance between the closest point of approach of two trajectories.';


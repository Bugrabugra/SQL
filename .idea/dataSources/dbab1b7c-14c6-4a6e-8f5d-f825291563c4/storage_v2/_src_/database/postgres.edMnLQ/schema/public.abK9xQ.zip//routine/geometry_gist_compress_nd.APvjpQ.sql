create function geometry_gist_compress_nd(internal
                                         ) returns internal
    language c
as
$$
gserialized_gist_compress
$$;


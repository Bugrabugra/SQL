create function st_clusterwithin(geometry, double precision
                                ) returns geometry[]
    language internal
as
$$
aggregate_dummy
$$;


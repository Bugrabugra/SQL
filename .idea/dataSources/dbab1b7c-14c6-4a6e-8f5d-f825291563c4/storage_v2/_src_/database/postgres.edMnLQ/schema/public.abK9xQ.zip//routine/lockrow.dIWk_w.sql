create function lockrow(text, text, text
                       ) returns integer
    language sql
as
$$
SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00');
$$;

comment on function lockrow(text, text, text, text, timestamp) is 'args: a_schema_name, a_table_name, a_row_key, an_auth_token, expire_dt - Sets lock/authorization for a row in a table.';


create function "_st_longestline"(geom1 geometry, geom2 geometry
                                 ) returns geometry
    language c
as
$$
LWGEOM_longestline2d
$$;


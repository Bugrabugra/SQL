create function geometry_gist_same_2d(geom1 geometry, geom2 geometry, internal
                                     ) returns internal
    language c
as
$$
gserialized_gist_same_2d
$$;


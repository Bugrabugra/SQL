create function "_postgis_stats"(tbl regclass, att_name text, text DEFAULT '2'::text
                                ) returns text
    language c
as
$$
_postgis_gserialized_stats
$$;


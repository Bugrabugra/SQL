create function postgis_typmod_type(integer
                                   ) returns text
    language c
as
$$
postgis_typmod_type
$$;


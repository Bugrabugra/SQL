create function postgis_typmod_srid(integer
                                   ) returns integer
    language c
as
$$
postgis_typmod_srid
$$;


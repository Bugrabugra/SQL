create function geometry_same_nd(geometry, geometry
                                ) returns boolean
    language c
as
$$
gserialized_same
$$;


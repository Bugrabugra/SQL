create function st_asencodedpolyline(geom geometry, nprecision integer DEFAULT 5
                                    ) returns text
    language c
as
$$
LWGEOM_asEncodedPolyline
$$;


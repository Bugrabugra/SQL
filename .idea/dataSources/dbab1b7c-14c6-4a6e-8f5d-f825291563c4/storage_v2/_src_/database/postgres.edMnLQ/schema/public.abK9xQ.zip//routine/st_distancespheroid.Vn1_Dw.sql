create function st_distancespheroid(geom1 geometry, geom2 geometry, spheroid
                                   ) returns double precision
    language c
as
$$
LWGEOM_distance_ellipsoid
$$;

comment on function st_distancespheroid(geometry, geometry, spheroid) is 'args: geomlonlatA, geomlonlatB, measurement_spheroid - Returns the minimum distance between two lon/lat geometries using a spheroidal earth model.';


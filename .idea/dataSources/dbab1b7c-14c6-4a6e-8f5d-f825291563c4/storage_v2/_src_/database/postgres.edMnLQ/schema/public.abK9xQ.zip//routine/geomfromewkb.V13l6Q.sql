create function geomfromewkb(bytea
                            ) returns geometry
    language c
as
$$
LWGEOMFromEWKB
$$;


create function box2df_in(cstring
                         ) returns box2df
    language c
as
$$
box2df_in
$$;


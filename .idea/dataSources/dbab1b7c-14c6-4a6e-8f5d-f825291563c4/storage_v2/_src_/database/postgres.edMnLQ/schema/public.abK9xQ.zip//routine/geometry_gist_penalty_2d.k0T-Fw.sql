create function geometry_gist_penalty_2d(internal, internal, internal
                                        ) returns internal
    language c
as
$$
gserialized_gist_penalty_2d
$$;


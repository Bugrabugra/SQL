create function geography_typmod_out(integer
                                    ) returns cstring
    language c
as
$$
postgis_typmod_out
$$;


create function postgis_libprotobuf_version(
                                           ) returns text
    language c
as
$$
postgis_libprotobuf_version
$$;


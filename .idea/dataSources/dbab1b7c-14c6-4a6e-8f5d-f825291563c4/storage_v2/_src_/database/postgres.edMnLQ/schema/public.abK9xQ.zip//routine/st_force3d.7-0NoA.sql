create function st_force3d(geometry
                          ) returns geometry
    language c
as
$$
LWGEOM_force_3dz
$$;

comment on function st_force3d(geometry) is 'args: geomA - Force the geometries into XYZ mode. This is an alias for ST_Force3DZ.';


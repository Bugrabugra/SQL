create function st_estimatedextent(text, text
                                  ) returns box2d
    language c
as
$$
gserialized_estimated_extent
$$;

comment on function st_estimatedextent(text, text) is 'args: table_name, geocolumn_name - Return the estimated extent of a spatial table.';


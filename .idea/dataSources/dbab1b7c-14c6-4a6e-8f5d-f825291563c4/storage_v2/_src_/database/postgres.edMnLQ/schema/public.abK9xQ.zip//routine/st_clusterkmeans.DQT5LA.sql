create function st_clusterkmeans(geom geometry, k integer
                                ) returns integer
    language c
as
$$
ST_ClusterKMeans
$$;

comment on function st_clusterkmeans(geometry, int4) is 'args: geom, number_of_clusters - Window function that returns a cluster id for each input geometry using the K-means algorithm.';


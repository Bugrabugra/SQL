create function st_dimension(geometry
                            ) returns integer
    language c
as
$$
LWGEOM_dimension
$$;

comment on function st_dimension(geometry) is 'args: g - Returns the topological dimension of a geometry.';


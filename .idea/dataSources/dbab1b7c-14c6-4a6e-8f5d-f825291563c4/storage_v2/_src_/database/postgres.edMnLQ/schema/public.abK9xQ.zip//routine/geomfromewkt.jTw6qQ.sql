create function geomfromewkt(text
                            ) returns geometry
    language c
as
$$
parse_WKT_lwgeom
$$;


create function geometry_gist_distance_2d(internal, geometry, integer
                                         ) returns double precision
    language c
as
$$
gserialized_gist_distance_2d
$$;


create function st_ashexewkb(geometry
                            ) returns text
    language c
as
$$
LWGEOM_asHEXEWKB
$$;


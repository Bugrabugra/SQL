create function geometry_gist_union_2d(bytea, internal
                                      ) returns internal
    language c
as
$$
gserialized_gist_union_2d
$$;


create function geometrytype(geometry
                            ) returns text
    language c
as
$$
LWGEOM_getTYPE
$$;

comment on function geometrytype(geometry) is 'args: geomA - Returns the type of a geometry as text.';


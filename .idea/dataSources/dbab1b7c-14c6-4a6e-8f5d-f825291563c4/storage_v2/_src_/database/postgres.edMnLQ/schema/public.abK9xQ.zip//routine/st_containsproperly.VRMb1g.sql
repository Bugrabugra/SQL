create function st_containsproperly(geom1 geometry, geom2 geometry
                                   ) returns boolean
    language c
as
$$
containsproperly
$$;


create function st_geometryfromtext(text
                                   ) returns geometry
    language c
as
$$
LWGEOM_from_text
$$;


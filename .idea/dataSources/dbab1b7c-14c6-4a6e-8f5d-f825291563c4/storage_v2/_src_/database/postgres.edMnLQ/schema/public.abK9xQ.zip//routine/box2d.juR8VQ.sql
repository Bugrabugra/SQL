create function box2d(geometry
                     ) returns box2d
    language c
as
$$
LWGEOM_to_BOX2D
$$;

comment on function box2d(geometry) is 'args: geomA - Returns a BOX2D representing the 2D extent of the geometry.';


create function st_geohash(geom geometry, maxchars integer DEFAULT 0
                          ) returns text
    language c
as
$$
ST_GeoHash
$$;


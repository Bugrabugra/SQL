create function st_closestpoint(geom1 geometry, geom2 geometry
                               ) returns geometry
    language c
as
$$
LWGEOM_closestpoint
$$;

comment on function st_closestpoint(geometry, geometry) is 'args: g1, g2 - Returns the 2D point on g1 that is closest to g2. This is the first point of the shortest line.';


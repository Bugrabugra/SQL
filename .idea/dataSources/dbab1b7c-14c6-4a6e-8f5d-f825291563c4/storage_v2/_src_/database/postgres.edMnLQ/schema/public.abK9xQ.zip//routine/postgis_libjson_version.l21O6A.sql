create function postgis_libjson_version(
                                       ) returns text
    language c
as
$$
postgis_libjson_version
$$;


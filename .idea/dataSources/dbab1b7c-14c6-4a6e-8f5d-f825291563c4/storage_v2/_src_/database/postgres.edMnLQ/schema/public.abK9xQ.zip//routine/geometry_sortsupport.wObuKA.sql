create function geometry_sortsupport(internal
                                    ) returns void
    language c
as
$$
lwgeom_sortsupport
$$;


create function st_3dmakebox(geom1 geometry, geom2 geometry
                            ) returns box3d
    language c
as
$$
BOX3D_construct
$$;

comment on function st_3dmakebox(geometry, geometry) is 'args: point3DLowLeftBottom, point3DUpRightTop - Creates a BOX3D defined by two 3D point geometries.';


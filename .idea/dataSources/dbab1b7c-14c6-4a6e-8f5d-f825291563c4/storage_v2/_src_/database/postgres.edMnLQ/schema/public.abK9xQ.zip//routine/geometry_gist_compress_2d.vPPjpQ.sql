create function geometry_gist_compress_2d(internal
                                         ) returns internal
    language c
as
$$
gserialized_gist_compress_2d
$$;


create function geography_distance_knn(geography, geography
                                      ) returns double precision
    language c
as
$$
geography_distance_knn
$$;


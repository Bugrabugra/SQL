create function st_hasarc(geometry geometry
                         ) returns boolean
    language c
as
$$
LWGEOM_has_arc
$$;

comment on function st_hasarc(geometry) is 'args: geomA - Tests if a geometry contains a circular arc';


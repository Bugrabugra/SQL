create function postgis_noop(geometry
                            ) returns geometry
    language c
as
$$
LWGEOM_noop
$$;


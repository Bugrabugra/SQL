create function geography_typmod_in(cstring[]
                                   ) returns integer
    language c
as
$$
geography_typmod_in
$$;


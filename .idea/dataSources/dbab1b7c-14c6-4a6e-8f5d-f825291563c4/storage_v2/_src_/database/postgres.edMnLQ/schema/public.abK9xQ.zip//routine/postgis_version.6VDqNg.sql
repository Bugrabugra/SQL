create function postgis_version(
                               ) returns text
    language c
as
$$
postgis_version
$$;

comment on function postgis_version() is 'Returns PostGIS version number and compile-time options.';


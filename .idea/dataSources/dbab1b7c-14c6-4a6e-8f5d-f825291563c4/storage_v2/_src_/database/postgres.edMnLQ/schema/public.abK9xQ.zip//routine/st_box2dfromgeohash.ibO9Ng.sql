create function st_box2dfromgeohash(text, integer DEFAULT NULL::integer
                                   ) returns box2d
    language c
as
$$
box2d_from_geohash
$$;

